


#python 2.x
try:
    with open("realestate.csv","r") as fobj:
        for line in fobj:
            line = line.strip()
            data = line.split(",")
            print"Street :", data[0]
            print "City   :", data[1]
            print("------------")
except IOError , err:
    print(err)
    
    
