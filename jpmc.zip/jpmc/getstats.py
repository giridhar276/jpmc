# -*- coding: utf-8 -*-
"""
Created on Thu Aug 19 11:07:14 2021

@author: gsripath
"""

import psutil
import os
import shutil
try:
    print(shutil.disk_usage("D:\\"))
    print(psutil.cpu_percent())
except Exception , err:
    print(err)











