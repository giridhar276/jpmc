### using csv library

## not required to split each line
# it is automatically with library

import csv
with open("realestate.csv","r") as fobj:
    ## converting file object ----> csv object using csv.reader
    data = csv.reader(fobj)
    for line in data:
        print(line)


import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    ## converting file object ----> csv object using csv.reader
    data = csv.reader(fobj)
    for line in data:
        cityset.add(line[1])
    for city in cityset:
        print(city)
