


adict = {"chap1":10 ,"chap2":20}

print(adict['chap1'])
print(adict['chap2'])

adict['chap5'] = 50


bookinfo   =  {"chap1":[10,"Rita","UK"] ,"chap2":[20,"Ram","US"] }
print(bookinfo['chap1'])
print(bookinfo['chap2'])
print(bookinfo['chap2'][2])

print(bookinfo)


bookinfo   =  {"chap1":[10,"Rita","UK"] ,"chap2":{"author":"Amit","Country":[10,"Rita","UK"] } }
print(bookinfo['chap1'])
print(bookinfo['chap2'])
print(bookinfo['chap2'][2])

print(bookinfo['chap2']['author'])
print(bookinfo['chap2']['Country'][1])



data = {
    "glossary": {
        "title": "example glossary",
		"GlossDiv": {
            "title": "S",
			"GlossList": {
                "GlossEntry": {
                    "ID": "SGML",
					"SortAs": "SGML",
					"GlossTerm": "Standard Generalized Markup Language",
					"Acronym": "SGML",
					"Abbrev": "ISO 8879:1986",
					"GlossDef": {
                        "para": "A meta-markup language, used to create markup languages such as DocBook.",
						"GlossSeeAlso": ["GML", "XML"]
                    },
					"GlossSee": "markup"
                }
            }
        }
    }
}
print(data['glossary']['GlossDiv']['GlossList']['GlossEntry']['GlossTerm'])
print(data['glossary']['GlossDiv']['GlossList']['GlossEntry']['GlossDef']['GlossSeeAlso'][0])

























