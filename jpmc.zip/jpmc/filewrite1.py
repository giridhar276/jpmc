
## writing text to the file
fobj = open("clients.txt","w")
fobj.write("unix programming\n")
fobj.write("scala programming\n")
fobj.close()




fobj = open("numbers.txt","w")

for val in range(1,101):
    fobj.write(str(val) + "\n")
fobj.close()



## creating file in different path
fobj = open("D:\\test\\clients.txt","w")
#fobj = open(r"D:\test\clients.txt","w")  # prefixing with r
#fobj = open("D:/test/clients.txt","w")   # using forward slash

fobj.write("unix programming\n")
fobj.write("scala programming\n")

fobj.close()









