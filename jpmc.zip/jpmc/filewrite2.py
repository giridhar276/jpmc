


fobj = open("numbers111.txt","w")
for val in range(1,101):
    fobj.write(str(val) + "\n")
fobj.close()



with open("numbers111.txt","a") as fobj:
    for val in range(10,20):
        fobj.write(str(val) + "\n")