

# deseralization
import pickle

dbfile = open('examplePickle.pkl', 'rb')

db = pickle.load(dbfile)

dbfile.close()



# now we the data accordingly
for key,value in db.items():
    print(key,value)
