alist = [10,5,44,43643,4,3575,2]

print(alist)
## adding single object
alist.append(50)
print("After appending :", alist)



## pass some set of values ... iterable
alist.extend([56,67,78])
print("After extending :", alist)

## check for no. of times item has been repeated
print(alist.count(10))

#    list.insert(index,position)   # object.insert(where to insert , what to insert)
alist.insert(0,5)
print("After inserting :", alist)
alist.insert(3,3000)
print("After inserting :", alist)

# value at that index 0 will be removed
alist.pop(0)
print("After pop opreation :",alist)

alist.remove(10)  # here 10 is the value    #### NOT index

# sorting in ascending by default
alist.sort()
print("After sorting :", alist)

# displaying reverse order
alist.reverse()
print("After reversing :", alist)


alist = [10,20,30]
alist.reverse()
alist.append(40)
alist.reverse()
alist




for val in alist:
    print(val)




for i in range(1,10):
    print(i)








