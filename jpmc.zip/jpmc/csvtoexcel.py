import csv
import os
import time
from openpyxl import Workbook
wb = Workbook()
# grab the active worksheet
ws = wb.active
excelfile = time.strftime("%d_%b_%Y.xlsx")
# if excel file already exists.. delete it
if os.path.exists(excelfile):
    os.remove(excelfile)
try:
    flatfile ="realestate.csv" 
    if os.path.isfile(flatfile):
        with open(flatfile,"r") as fobj:
            # convert fobj to csv object
            reader = csv.reader(fobj)
            for line in reader:
                ws.append(line)                
            wb.save(excelfile)
    else:
        print("Input file(csv) doesn't exist")
except Exception as err:
    print(err)