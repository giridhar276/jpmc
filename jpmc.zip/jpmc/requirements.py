

import os



#os.unlink('filewrite1.html')


#print(os.listdir(os.getcwd()))

for afile in os.listdir("C:\\"):
    print(afile)
    
    
for val in range(1,100):
    os.mkdir("dir" + str(val))  