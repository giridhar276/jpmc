



import sqlite3

conn = sqlite3.connect('test.db')
print("Opened database successfully")

query = "create table realestate (street varchar(100) , city varchar(100)) "
conn.execute(query)


print("Table created successfully")

conn.close()


