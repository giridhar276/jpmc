

#### using fobj.readlines()
try:
    with open("realestate.csv","r") as fobj:
        data = fobj.readlines()
        #print(data)
        for line in data:
            print(line)
except IOError , err:
    print(err)
    
    
## not generally suggested for reading flat files
## everything gets captured to the string    
# using fobj.read()
try:
    with open("realestate.csv","r") as fobj:
        print(fobj.read())
except IOError , err:
    print(err)    