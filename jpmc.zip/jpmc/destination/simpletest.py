

# In python 2.x
print "hello","hi"

# In python 3.x
print("hello","hi")



