name = "python programming"

print(name.capitalize())
print(name)
print(name.upper())
print(name.lower())
print(name.center(50))
print(name.center(50,"*"))
print(name.count("p"))
print(name.count("prog"))
print(name.endswith("z"))
print(name.endswith("g"))
print(name.startswith("m"))
print(name.startswith("p"))

a,b = 100,2
if a < b :
    print("B is largest")
    print("Iside if")
    print("Still inside if")
else:
    print("A is largest")


if name.startswith("p"):
    print("name is starting with p")
else:
    print("name is starting with someother char")
 

if name.isupper():
    print("String is defined in uppercase")
else:
    print("string is defined in lowercase")
        

print(name)
print(name.find('r'))   # if exists... will return the index number
print(name.find('z'))   # if not existing.. will return -1

## method1 :  check foe existence
if name.find('r') != -1 :
    print("substring exists")
else:
    print("substring doesnt exist")

## method2:
if name.count('p') > 0:
    print("substring exists")
else:
    print("doesn't exist")

data = "python "
print(len(data))
print(len(data.strip()))   # whitespace is removed


info = "I love {} and {}"
print(info.format("python","hadoop"))

info = "I love {0} and {1}"
print(info.format("python","hadoop"))

info = "I love {1} and {0}"
print(info.format("python","hadoop"))

info = "perl,unix,java,oracle"
print(info.split(','))


















