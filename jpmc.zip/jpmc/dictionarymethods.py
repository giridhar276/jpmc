adict = {"chap1":10 ,"chap2":20}
print(adict)
print(adict)
# only keys
print(adict.keys())
# only values
print(adict.values())
## display key-value pairs
print(adict.items())

#print(adict['chap3'])

# If key is not available it will return None
#print(adict['chap3'])
print(adict.get('chap3'))

# iterate only keys
for key in adict.keys():
    print(key)
    
# display only values
for value in adict.values():
    print(val)
    
# display key:value pair
for key,value in adict.items():
    print(key,value)
    


