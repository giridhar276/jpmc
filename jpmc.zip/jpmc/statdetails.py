    


import psutil
import os
import shutil
import sys
try:
    print(psutil.disk_usage("D:\\"))
    print(psutil.cpu_percent())
    print(psutil.virtual_memory())
    # you can convert that object to a dictionary 
    print(dict(psutil.virtual_memory()._asdict()  ) )
except Exception , err:
    print(err)
    print(sys.exc_info())
    
    
    
