
filename = raw_input("Enter any filename :")
if "." in filename:
    if filename.endswith(".py"):
        print("Its python file")
    elif filename.endswith(".sh"):
        print("its shell file")
    elif filename.endswith(".pl"):
        print("Its perl file")
    else:
        print("Its someother file")
else:
    print("filename is not ending with .")    


filename = raw_input("Enter any filename :")
if "." in filename:
    output = filename.split(".")
if output[1] == "py":
    print("Its python file")
elif output[1] == "sh":
    print("its shell file")
elif output[1] == "pl":
    print("Its perl file")
else:
    print("Its someother file")    