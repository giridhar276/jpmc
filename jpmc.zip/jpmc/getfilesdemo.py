

## from current directory
import os

for getfile in os.listdir(os.getcwd()):
    print(getfile)
    
    
## different directory
import os

for getfile in os.listdir("D:\\"):
    print(getfile)    