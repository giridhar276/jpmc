



aset = {10,20,30,10,20}
aset.add(100)
print(aset)



bset = {30,40,40,50,50}
print(aset)
print(bset)


print(aset.intersection(bset))
print(aset.union(bset))
print(aset.issubset(bset))
print(aset.issuperset(bset))





