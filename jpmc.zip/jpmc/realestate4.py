#python 2.x
cityset = set()
try:
    with open("realestate.csv","r") as fobj:
        ### processing the data
        header = fobj.readline()
        for line in fobj:
            line = line.strip()
            data = line.split(",")
            cityname = data[1]
            cityset.add(cityname)
        ## displaying the data    
        for city in cityset:
            print(city)
except IOError , err:
    print(err)
    
############### 2nd approach #############
citydict = dict()
try:
    with open("realestate.csv","r") as fobj:
        ### processing the data
        header = fobj.readline()
        for line in fobj:
            line = line.strip()
            data = line.split(",")
            cityname = data[1]
            ## creating new key:value pair
            citydict[cityname] =1
        ## displaying the data    
        for city in citydict.keys():
            print(city)
except IOError , err:
    print(err)