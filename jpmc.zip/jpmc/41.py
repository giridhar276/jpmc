fixed = "192.168.0."
for val in range(1,11):
    print(fixed + str(val))
    
    
fixed = "192.168.0."
for val in range(1,11):
    ip = fixed + str(val)
    print(ip)  
    

IP = []
fixed = "192.168."
for val in range(0,2):
    ip = fixed + str(val) + "."
    for value in range(1,11):
        print(ip + str(value))
    
##### storing all the Ips to the list
IP = []
fixed = "192.168."
for val in range(0,2):
    ip = fixed + str(val) + "."
    for value in range(1,11):
        final = ip + str(value)
        IP.append(final)
        #print(final)

#print(IP)    
for newip in IP:
    print(newip)