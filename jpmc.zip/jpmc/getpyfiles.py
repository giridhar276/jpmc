
### display files and its size
import os


for getfile in os.listdir(os.getcwd()):
    if getfile.endswith(".py"):
        #print(getfile)
        size = os.path.getsize(getfile)
        print getfile.ljust(20),size,"bytes"