# for loop using string
name = "python"
for char in name:
    print(char)

# for loop with range()
for val in range(1,5):
    print(val)

## for loop with odd numbers from 1 to 100    # range(start,stop,step)
for val in range(1,101,2):
    print(val)

# for loop with even numbers
for val in range(2,101,2):
    print(val)

# for with list
alist = [10,20,30,40]
for val in alist:
    print(val)


# for with dictionary
book = {"chap1":10 , "chap2":20}
for key in book.keys():
    print(key)
for value in book.values():
    print(value)
for key,value in book.items():
    print(key,value)







