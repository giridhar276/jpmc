


alist = ["google","oracle","microsoft"]


for company in alist:
    name = "http://www." + company + ".com"
    print(name)

