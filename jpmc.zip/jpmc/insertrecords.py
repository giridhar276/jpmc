

####  inserting records to db
import sqlite3

conn = sqlite3.connect('test.db')
print ("Opened database successfully")

query1 = "insert into realestate( street,city) values('{0}','{1}')".format('MG Road','Noida')
conn.execute(query1)

query2 = "insert into realestate( street,city) values('{0}','{1}')".format('Banjara Hills','Hyderabad')
conn.execute(query2)


conn.commit()

print("Records created successfully")
conn.close()

