
# Python 2.x
try:
    filename = raw_input("Enter any filename :")
    with open(filename,"r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except IOError ,err :
    print("File doesn't exist")
except TypeError , error :
    print("Sytem error message :" + str(error))
    print("Custom message :" , "Invalid operation")
except ValueError , error:
    print(error)
    print("Invalid input")
except (IndexError,KeyError) , error :
    print(error)
except Exception , error:
    print(error)
