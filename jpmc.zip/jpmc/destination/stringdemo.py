
# string[start:stop:step]
# slice
name = "python programming"

print(name)

print(name[0])
print(name[1])
print(name[0:4])
print(name[4:9])
print(name[:])    # python programming
print(name[::])   # python programming
print(name[0:17])
print(name[0:17:1])
print(name[0:17:2])
print(name[1:17:2])
print(name[1:17:3])
print(name[-1])
print(name[::-1])     #gnimmargorp nohtyp


