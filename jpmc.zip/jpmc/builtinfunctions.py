print("hello")



print(range(1,10))

alist = [34,45,12]
print(max(alist))
print(min(alist))
print(sum(alist))

name = "python"
print(type(name))
print(isinstance(name,str))
print(isinstance(name,list))

name = raw_input("Enter your name :")
print("You have entered :",name)

print(id(name))
alist = [10,20,430]
print(id(alist))


alist = [23333,2]
print(alist)


