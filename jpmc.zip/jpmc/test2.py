


from openpyxl import Workbook
wb = Workbook()
# grab the active worksheet
ws = wb.active



for val in range(1,101):
    ws.append([val])


# Save the file
wb.save('numbers1.xlsx')