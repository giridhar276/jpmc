

### all the methods from library will be imported
# we use . to access the methods
import math
print(math.log(2))
print(math.tan(1))

# importing using alias name
import math as m
print(m.log(3))
print(m.floor(34.4))


## importing required methods ONLY
from math import log
from math import ceil,floor,tan
from math import factorial
print(log(2))
print(ceil(45.56))






