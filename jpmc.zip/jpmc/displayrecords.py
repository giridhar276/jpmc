
#### displaying the records

import sqlite3

conn = sqlite3.connect('test.db')
print("Opened database successfully")

query = "SELECT * from realestate"
cursor = conn.execute(query)

for row in cursor:
   print("STREET : ", row[0])
   print("CITY  :", row[1])
   print("------")

print("Operation done successfully")
conn.close()