



ip = raw_input("Enter IP:")

data = ip.split(".")

if len(data) == 4:
    if int(data[0]) in range(1,256) and int(data[1]) in range(0,256) and int(data[2]) in range(0,256) and int(data[3]) in range(1,256):
        print("Its valid IP")
    else:
        print("Invalid IP")
else:
    print("Invalid IP")