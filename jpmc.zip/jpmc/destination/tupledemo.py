
atup  = (10,20,30,40)
print "Tuple values are :", atup

## display error : TypeError
#atup[0] = "java"
print "After replacing :",atup


## converting to list to make changes : typecasting
# applying my changes
alist = list(atup)
alist[2] = 2000
# recoverting back to tuple
atup = tuple(alist)
print(atup)


atuple=(10,20,30)
print(atuple)
tlist=list(atuple)
tlist[0]=1000
atuple=tuple(tlist)
print(atuple)