


## copy files
import os
import shutil
source= r"C:\Users\gsripath\Desktop\jpmc\source"
destination = r"C:\Users\gsripath\Desktop\jpmc\destination"

for afile in os.listdir(source):
    #print afile
    shutil.copy(source + "\\" +  afile , destination)