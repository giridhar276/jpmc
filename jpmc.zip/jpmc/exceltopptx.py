

from pptx import Presentation
import openpyxl
wb = openpyxl.load_workbook("directions.xlsx")
ws = wb['Sheet1']
ppt = Presentation('template1.pptx')
layout_swot = ppt.slide_layouts[5]  # I use layout 'ID=5'
new_slide = ppt.slides.add_slide(layout_swot)
new_slide.placeholders[1].text  = str(ws['B2'].value)
new_slide.placeholders[3].text  = str(ws['B3'].value)
new_slide.placeholders[13].text = str(ws['B4'].value)
new_slide.placeholders[14].text = str(ws['B5'].value)
ppt.save("sample00.pptx")