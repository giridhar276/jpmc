#python 2.x
try:
    with open("realestate.csv","r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except IOError , err:
    print(err)
    
    
