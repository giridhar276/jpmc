
alist =[10,20,30,40,56,5,43,43]
print(alist)
print(alist[0])
print(alist[0:5])


blist = [10,20,"hadoop","java"]
print(blist[2])
print(blist[0:4])

alist[0] = 1000
print "After replacing:", alist

