
## 
import requests   # http connection
from bs4 import BeautifulSoup

## trying to establish http connection
response = requests.get("https://www.techworldguru.com/")

#print(response.status_code)

if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))
    
else:
    print(response.status_code)