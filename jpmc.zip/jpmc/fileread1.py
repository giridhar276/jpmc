
# fobj can be called as handler or cursor or pointer
fobj = open("languages.txt","r")

for line in fobj:
    ## for removing white spaces
    line = line.strip()
    print(line)
fobj.close()



## context manager
## Every context manager starts with keyword with
## File gets closed automatically.. not required to close
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
        
        
        
        
        
        
        