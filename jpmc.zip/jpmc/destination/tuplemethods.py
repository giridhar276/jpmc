


atup = (10,20,5)

atup.count(20)



for val in atup:
    print(val)