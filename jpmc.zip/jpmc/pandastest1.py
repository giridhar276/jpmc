



import pandas as pd

df = pd.read_csv(r'C:\Users\gsripath\Desktop\jpmc\pandas_assignments\01_Getting_&_Knowing_Your_Data\Occupation\u.user')

# display only top 5 records
print(df.head(5))

# display only last 5 records
print(df.tail(5))