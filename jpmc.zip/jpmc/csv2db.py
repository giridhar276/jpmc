
import csv
import sqlite3
import os
##################### inserting records ################
querytemplate = "insert into realestate( street,city) values('{0}','{1}')"

# sqlite3
conn = sqlite3.connect('test.db')
## mysql
conn = pymysql.connect(host='12.12.3.3',port=3306,user='root',password='Noli')



print("Opened database successfully")

filename = "realestate.csv"
if os.path.isfile(filename) and os.path.getsize(filename) > 0 :
    with open(filename,"r") as fobj:
        ## convert fobj to csv object
        reader = csv.reader(fobj)
        for line in reader:
            street = line[0]
            city = line[1]
            query = querytemplate.format(street,city)
            #print(query)
            conn.execute(query)
        
conn.commit()
print("Records created successfully")
############################# displaying the records ###############
query = "SELECT * from realestate"
cursor = conn.execute(query)

for row in cursor:
   print "STREET : ", row[0]
   print "CITY  :", row[1]
   print("------")
conn.close()
